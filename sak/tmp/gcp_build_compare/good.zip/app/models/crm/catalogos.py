from typing import Optional, TYPE_CHECKING

from sqlmodel import Field, Relationship

from ..base import Base

if TYPE_CHECKING:
    from .contacto import CRMContacto
    from .evento import CRMEvento
    from .oportunidad import CRMOportunidad


class CRMTipoOperacion(Base, table=True):
    __tablename__ = "crm_tipos_operacion"
    __searchable_fields__ = ["codigo", "nombre"]
    __auto_include_enabled__ = False

    codigo: str = Field(max_length=50, description="Código único", unique=True, index=True)
    nombre: str = Field(max_length=100, description="Nombre del tipo de operación")
    descripcion: Optional[str] = Field(default=None, max_length=500)
    activo: bool = Field(default=True, description="Indica si el tipo está activo")

    oportunidades: list["CRMOportunidad"] = Relationship(
        back_populates="tipo_operacion",
        sa_relationship_kwargs={"lazy": "noload"}
    )


class CRMMotivoPerdida(Base, table=True):
    __tablename__ = "crm_motivos_perdida"
    __searchable_fields__ = ["codigo", "nombre"]

    codigo: str = Field(max_length=50, unique=True, index=True)
    nombre: str = Field(max_length=150)
    descripcion: Optional[str] = Field(default=None, max_length=500)
    activo: bool = Field(default=True)

    oportunidades: list["CRMOportunidad"] = Relationship(
        back_populates="motivo_perdida",
        sa_relationship_kwargs={"lazy": "noload"}
    )


class CRMCondicionPago(Base, table=True):
    __tablename__ = "crm_condiciones_pago"
    __searchable_fields__ = ["codigo", "nombre"]

    codigo: str = Field(max_length=50, unique=True, index=True)
    nombre: str = Field(max_length=200)
    descripcion: Optional[str] = Field(default=None, max_length=500)
    activo: bool = Field(default=True)

    oportunidades: list["CRMOportunidad"] = Relationship(
        back_populates="condicion_pago",
        sa_relationship_kwargs={"lazy": "noload"}
    )


class CRMTipoEvento(Base, table=True):
    __tablename__ = "crm_tipos_evento"
    __searchable_fields__ = ["codigo", "nombre"]

    codigo: str = Field(max_length=50, unique=True, index=True)
    nombre: str = Field(max_length=100)
    descripcion: Optional[str] = Field(default=None, max_length=500)
    activo: bool = Field(default=True)


class CRMMotivoEvento(Base, table=True):
    __tablename__ = "crm_motivos_evento"
    __searchable_fields__ = ["codigo", "nombre"]

    codigo: str = Field(max_length=50, unique=True, index=True)
    nombre: str = Field(max_length=150)
    descripcion: Optional[str] = Field(default=None, max_length=500)
    activo: bool = Field(default=True)


class Moneda(Base, table=True):
    __tablename__ = "monedas"
    __searchable_fields__ = ["codigo", "nombre"]

    codigo: str = Field(max_length=10, unique=True, index=True)
    nombre: str = Field(max_length=100)
    simbolo: str = Field(max_length=5)
    es_moneda_base: bool = Field(default=False)
    activo: bool = Field(default=True)

    oportunidades: list["CRMOportunidad"] = Relationship(back_populates="moneda")


class CRMCatalogoRespuesta(Base, table=True):
    __tablename__ = "crm_catalogo_respuestas"
    __searchable_fields__ = ["titulo", "texto"]

    titulo: str = Field(max_length=255, description="Título de la respuesta")
    texto: str = Field(default="", description="Contenido de la respuesta")
    activo: bool = Field(default=True, description="Indica si la respuesta está activa")